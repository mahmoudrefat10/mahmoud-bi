# Mahmoud BI
Turn Data Into Decisions. Dashboard marketplace, Phase 1 (static site).

- Site files: `public/` (Cloudflare Pages build output directory)
- Docs: `docs/` (CHANGELOG, TEST-REPORT, CONTENT-REVIEW)
- Regenerate pages: `python3 tools/build_site.py` (portfolio) and `python3 tools/gen_preview.py` (design previews)
- Local preview: `cd public && python3 -m http.server 8788`, then open http://localhost:8788/index.html
- Deploy: Cloudflare Pages, framework None, no build command, output directory `public`.
Never commit passwords, API keys or `.env` files to this repository.
