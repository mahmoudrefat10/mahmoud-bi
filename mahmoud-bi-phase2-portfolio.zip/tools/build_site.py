#!/usr/bin/env python3
"""Local helper (NOT a Cloudflare build step): optimizes images and writes public/index.html + sitemap.
Run: python3 tools/build_site.py   Language-ready: add an 'ar' entry to TXT later to emit /ar/index.html."""
import os,sys,json,shutil,html,urllib.parse
from PIL import Image
sys.path.insert(0,os.path.dirname(__file__));import portfolio_data as D
R=os.path.join(os.path.dirname(__file__),'..','public');SITE='https://mahmoud-bi.pages.dev'
WA='201127238627';e=html.escape
def wa(msg):return f'https://wa.me/{WA}?text='+urllib.parse.quote(msg,safe='')
TECH={'excel':'Excel','powerbi':'Power BI','html':'HTML / CSS / JavaScript'}
def order_msg(p):return f"Hello Mahmoud,\n\nI visited your Mahmoud BI portfolio and I'm interested in ordering a dashboard similar to:\n\nProject: {p['title']}\n\nTechnology: {TECH[p['cat']].upper() if p['cat']!='html' else 'HTML'}\n\nI would like to discuss the requirements, pricing, and delivery time.\n\nPlease contact me with more details.\n\nThank you."
def gen_msg(topic=None):
    t=f"I'm interested in your {topic} service" if topic else "I'd like to request a custom dashboard"
    return f"Hello Mahmoud,\n\nI visited your Mahmoud BI website and {t}.\n\nI would like to discuss the requirements, pricing, and delivery time.\n\nPlease contact me with more details.\n\nThank you."
# ---------- images ----------
out=os.path.join(R,'assets','portfolio');shutil.rmtree(out,ignore_errors=True);os.makedirs(out)
for p in D.PROJECTS:
    p['imgs']=[]
    for i,f in enumerate(p['files'],1):
        d=os.path.join(out,p['id']);os.makedirs(d,exist_ok=True)
        ext=f.rsplit('.',1)[-1].lower();ext='jpg' if ext=='jpeg' else ext
        orig=f'{i}.{ext}';shutil.copyfile(D.SRC+f,os.path.join(d,orig))          # original bytes, untouched
        im=Image.open(D.SRC+f).convert('RGB');w=min(720,im.width);t=im.resize((w,round(im.height*w/im.width)),Image.LANCZOS)
        t.save(os.path.join(d,f'{i}-720.webp'),quality=84,method=6)
        p['imgs'].append(dict(src=f'/assets/portfolio/{p["id"]}/{orig}',thumb=f'/assets/portfolio/{p["id"]}/{i}-720.webp',w=t.width,h=t.height,ow=im.width,oh=im.height,alt=p['alt'][min(i-1,len(p['alt'])-1)]+(f' (screenshot {i} of {len(p["files"])})' if len(p['files'])>1 else '')))
# hero collage (960px webp from three published screenshots)
hero=[('sales-performance-web-dashboard','sales'),('orange-business-intelligence-dashboard','bi'),('luxury-perfume-sales-dashboard','perfume')]
for pid,n in hero:
    q=[x for x in D.PROJECTS if x['id']==pid][0];im=Image.open(D.SRC+q['files'][0]).convert('RGB');w=min(960,im.width)
    im.resize((w,round(im.height*w/im.width)),Image.LANCZOS).save(os.path.join(R,'assets','portfolio',f'hero-{n}.webp'),quality=86,method=6)
# ---------- content ----------
SERV=[('Excel Dashboard Development','Familiar, flexible Excel dashboards your team can update and use every day.','xl'),
('Power BI Dashboard Development','Interactive Power BI reports that let decision-makers explore the numbers themselves.','pbi'),
('Interactive HTML Dashboards','Responsive web dashboards built with HTML, CSS and JavaScript for a polished, branded experience.','html'),
('Business Intelligence Reporting','Executive and KPI reporting designed around the questions your business needs answered.','rep'),
('Data Visualization','Clear charts and layouts that turn complex tables into a story people can act on.','vis'),
('Dashboard Customization','Adapt an existing dashboard to your data, branding, filters and KPIs.','cus'),
('Automated Reporting Solutions','Recurring reports set up to refresh with less manual effort.','aut')]
EXP=[('Data Analysis & Business Insights','Exploring data to find trends, drivers and the story behind the numbers.'),
('BI & Executive Reporting','KPI reports and dashboards shaped for managers and decision-makers.'),
('Interactive Dashboard Development','Excel, Power BI and web dashboards with filters, slicers and drill-downs.'),
('Data Cleaning & Validation','Collecting, cleaning and transforming raw data so reports can be trusted.'),
('Reporting Automation','Reducing repetitive manual reporting work with refreshable reports.'),
('Healthcare & Public Health Analytics','Disease surveillance reporting and epidemiology-aligned analysis.'),
('Data Visualization & Storytelling','Presenting findings to leadership and stakeholders with clear visuals.'),
('AI-Assisted KPI Monitoring','Systems built with Claude AI for KPI alerts and natural-language questions about business data.')]
WHY=[('Starts from your business question','Every dashboard begins with what you need to decide, not with a chart type.'),
('Years of real reporting discipline','Since October 2017 working with health datasets where accuracy and clarity matter.'),
('Three technologies, one specialist','Excel, Power BI and HTML dashboards, so the tool fits your team.'),
('Executive-ready visuals','Clean layouts that leadership can read in seconds.'),
('Customizable and editable','Branding, filters and KPIs adjusted to your data.'),
('Direct communication','You talk to the person who builds your dashboard, on WhatsApp.')]
SKILLS=[('Business Intelligence','Power BI, Tableau, KPI dashboards, executive dashboards, data storytelling'),
('Data preparation','Power Query, ETL processes, data cleaning, transformation and validation'),
('Modeling & spreadsheets','Data modeling, DAX, Power Pivot, Microsoft Excel (advanced)'),
('Web dashboards','HTML, CSS, JavaScript, responsive dashboard design'),
('Analytics & reporting','Exploratory analysis, trend analysis, KPI tracking, executive reporting, reporting automation'),
('Domain & AI','Healthcare analytics, public health, epidemiology, disease surveillance, Claude AI')]
CERT=[('Inequality Analysis Using Excel: Disaggregated Data','World Health Organization (WHO)','Jan 2024'),('Building Additional Dashboards in Power BI','World Health Organization (WHO)','Jan 2024'),
('Discover Data Analysis','Microsoft Learn',''),('Get Started Building with Power BI','Microsoft Learn',''),('Design Power BI Reports','Microsoft Learn',''),('Perform Data Analysis in Power BI','Microsoft Learn',''),
('Dashboards and Visualization','LinkedIn Learning',''),('Data Visualization for Data Analysts and Analytics','LinkedIn Learning','')]
IC={'xl':'<path d="M3 5h18v14H3zM3 10h18M9 5v14"/>','pbi':'<path d="M6 20V11M12 20V5M18 20v-6"/>','html':'<path d="M8 8l-5 4 5 4M16 8l5 4-5 4M14 5l-4 14"/>','rep':'<path d="M6 3h9l4 4v14H6zM14 3v5h5M9 13h7M9 17h7"/>','vis':'<path d="M3 20h18M6 16l4-5 4 3 5-7"/>','cus':'<path d="M4 6h10M18 6h2M4 12h2M10 12h10M4 18h12M20 18h0"/><circle cx="16" cy="6" r="2"/><circle cx="8" cy="12" r="2"/><circle cx="18" cy="18" r="2"/>','aut':'<path d="M21 12a9 9 0 1 1-3-6.7M21 4v5h-5"/>'}
ic=lambda k:f'<div class="icon-tile"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">{IC[k]}</svg></div>'
WAI='<svg class="wai" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 12a8.5 8.5 0 0 1-12.6 7.4L3 21l1.7-5.2A8.5 8.5 0 1 1 21 12z"/></svg>'
ARR='<span class="arr" aria-hidden="true">→</span>'
PUB=[p for p in D.PROJECTS if p['publish']]
cnt={c:sum(p['cat']==c for p in PUB) for c in('excel','powerbi','html')}
NAV=[('#top','Home'),('#about','About'),('#expertise','Expertise'),('#portfolio','Portfolio'),('#services','Services'),('#contact','Contact')]
def card(p):
    c=p['imgs'][0];n=len(p['imgs'])
    return f'''<article class="card pcard" data-cat="{p['cat']}" data-ind="{e(p['industry'])}" data-title="{e(p['title'].lower())} {e(p['industry'].lower())}" data-id="{p['id']}"><button class="pimg" type="button" data-open="{p['id']}" aria-label="View {e(p['title'])}"><img src="{c['thumb']}" width="{c['w']}" height="{c['h']}" alt="{e(c['alt'])}" loading="lazy" decoding="async">{f'<span class="count">{n} screenshots</span>' if n>1 else ''}</button><div class="pbody"><div class="tags"><span class="tag tech">{TECH[p['cat']]}</span><span class="tag">{e(p['industry'])}</span>{f'<span class="tag demo">{e(p["sample"])}</span>' if p['sample'] else ''}</div><h3>{e(p['title'])}</h3><p>{e(p['desc'])}</p><div class="pbtns"><button class="btn btn-ghost sm" type="button" data-open="{p['id']}">View Project</button><a class="btn btn-primary sm" href="{wa(order_msg(p))}" target="_blank" rel="noopener">{WAI}Order Similar Dashboard</a></div></div></article>'''
cards='\n'.join(card(p) for p in PUB)
data=json.dumps([dict(id=p['id'],title=p['title'],tech=TECH[p['cat']],industry=p['industry'],desc=p['desc'],hl=p['hl'],sample=p['sample'],wa=wa(order_msg(p)),imgs=[dict(src=i['src'],alt=i['alt'],w=i['ow'],h=i['oh']) for i in p['imgs']]) for p in PUB],ensure_ascii=False).replace('</','<\\/')
inds=sorted({p['industry'] for p in PUB})
tabs=[('all','All Projects',len(PUB)),('excel','Excel Dashboards',cnt['excel']),('powerbi','Power BI Dashboards',cnt['powerbi']),('html','HTML Dashboards',cnt['html'])]
tabh=''.join(f'<button class="tab" role="tab" id="tab-{k}" data-tab="{k}" aria-selected="{"true" if k=="all" else "false"}" aria-controls="grid">{l} <span class="n">{n}</span></button>' for k,l,n in tabs)
svc=''.join(f'<article class="card rv">{ic(k)}<h3>{e(t)}</h3><p>{e(d)}</p><a class="link" href="{wa(gen_msg(t))}" target="_blank" rel="noopener">{WAI}Inquire on WhatsApp</a></article>' for t,d,k in SERV)
exp=''.join(f'<article class="card rv"><h3>{e(t)}</h3><p>{e(d)}</p></article>' for t,d in EXP)
why=''.join(f'<div class="why rv"><h3>{e(t)}</h3><p>{e(d)}</p></div>' for t,d in WHY)
sk=''.join(f'<article class="card rv"><h3>{e(t)}</h3><p>{e(d)}</p></article>' for t,d in SKILLS)
cert=''.join(f'<li><b>{e(t)}</b><span>{e(i)}{(" · "+d) if d else ""}</span></li>' for t,i,d in CERT)
nav=''.join(f'<li><a href="{h}">{n}</a></li>' for h,n in NAV);dr=''.join(f'<a class="dl" href="{h}">{n}<span aria-hidden="true">→</span></a>' for h,n in NAV)
GEN=wa(gen_msg())
header=f'''<a class="skip" href="#main">Skip to content</a><header class="site-header"><div class="wrap nav"><a class="brand" href="/" aria-label="Mahmoud BI home"><picture><source srcset="/assets/logo/mahmoud-bi-logo-480.webp" type="image/webp"><img src="/assets/logo/mahmoud-bi-logo-480.png" width="480" height="291" alt="Mahmoud BI logo"></picture></a><nav aria-label="Main"><ul class="nav-links">{nav}</ul></nav><div class="nav-actions"><a class="btn btn-primary nav-cta" href="{GEN}" target="_blank" rel="noopener">{WAI}WhatsApp</a><button class="burger" id="burger" aria-label="Menu" aria-expanded="false" aria-controls="drawer"><span></span></button></div></div></header><div class="drawer" id="drawer">{dr}<a class="btn btn-primary" href="{GEN}" target="_blank" rel="noopener">{WAI}Request a Custom Dashboard</a></div>'''
footer=f'''<footer class="site-footer"><div class="wrap"><div class="fgrid"><div><div class="brand" style="display:inline-flex;margin-block-end:14px"><img src="/assets/logo/mahmoud-bi-logo-480.png" width="480" height="291" alt="Mahmoud BI" style="height:44px;width:auto" loading="lazy"></div><p>Mahmoud BI | Data Analyst &amp; Dashboard Designer. Excel, Power BI and interactive HTML dashboards.</p><a class="btn btn-primary" style="margin-block-start:14px;display:inline-flex" href="{GEN}" target="_blank" rel="noopener">{WAI}Request a Custom Dashboard</a></div><div><h4>Navigate</h4>{''.join(f'<a href="{h}">{n}</a>' for h,n in NAV)}</div><div><h4>Portfolio</h4><a href="#portfolio" data-go="excel">Excel Dashboards</a><a href="#portfolio" data-go="powerbi">Power BI Dashboards</a><a href="#portfolio" data-go="html">HTML Dashboards</a></div><div><h4>Connect</h4><a href="{GEN}" target="_blank" rel="noopener">WhatsApp</a><a href="mailto:mahmoudrefat105@gmail.com">Email</a><a href="https://www.linkedin.com/in/mahmoud-refat-b9b988293/" target="_blank" rel="noopener">LinkedIn</a><a href="https://www.youtube.com/@MahmoudRefatBI" target="_blank" rel="noopener">YouTube</a></div></div><p class="copy">© Mahmoud BI. All rights reserved.</p></div></footer>'''
heroimg=lambda n,c,w:f'<div class="shot {c}"><img src="/assets/portfolio/hero-{n}.webp" width="{w[0]}" height="{w[1]}" alt="{w[2]}"{" fetchpriority=\"high\"" if c=="s1" else " loading=\"lazy\""} decoding="async"></div>'
def hw(n):
    im=Image.open(os.path.join(out,f'hero-{n}.webp'));return im.size
s1,s2,s3=hw('sales'),hw('bi'),hw('perfume')
collage=heroimg('sales','s1',(*s1,'Interactive sales performance dashboard built with HTML, CSS and JavaScript'))+heroimg('bi','s2',(*s2,'Orange business intelligence dashboard built in Excel'))+heroimg('perfume','s3',(*s3,'Luxury perfume sales dashboard built in Excel'))
TITLE='Mahmoud BI | Data Analyst & Dashboard Designer: Excel, Power BI & HTML Dashboards'
DESC='Mahmoud BI by Mahmoud Refat: Data Analyst and BI dashboard developer. Browse real Excel and HTML dashboard projects and order a custom dashboard on WhatsApp.'
ld=json.dumps({"@context":"https://schema.org","@type":"Person","name":"Mahmoud Mohamed Refat","jobTitle":"Data Analyst | Business Intelligence & Dashboard Developer","url":SITE+"/","email":"mailto:mahmoudrefat105@gmail.com","telephone":"+201127238627","sameAs":["https://www.linkedin.com/in/mahmoud-refat-b9b988293/","https://www.youtube.com/@MahmoudRefatBI"],"worksFor":{"@type":"Organization","name":"Mahmoud BI"}},ensure_ascii=False)
page=f'''<!doctype html><html lang="en" dir="ltr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover"><title>{e(TITLE)}</title><meta name="description" content="{e(DESC)}"><link rel="canonical" href="{SITE}/"><meta name="theme-color" content="#070D1A"><meta property="og:type" content="website"><meta property="og:site_name" content="Mahmoud BI"><meta property="og:title" content="{e(TITLE)}"><meta property="og:description" content="{e(DESC)}"><meta property="og:url" content="{SITE}/"><meta property="og:image" content="{SITE}/assets/og-image.jpg"><meta property="og:image:width" content="1200"><meta property="og:image:height" content="630"><meta name="twitter:card" content="summary_large_image"><link rel="icon" href="/favicon.png"><script>document.documentElement.className+=" js"</script><link rel="preload" href="/fonts/outfit-latin-wght-normal.woff2" as="font" type="font/woff2" crossorigin><link rel="stylesheet" href="/css/fonts.css"><link rel="stylesheet" href="/css/design-system.css"><link rel="stylesheet" href="/css/portfolio.css"><script type="application/ld+json">{ld}</script></head><body id="top">{header}<main id="main">
<section class="hero"><div class="wrap"><div><span class="eyebrow">Mahmoud BI</span><h1 class="display">Turn Your Data Into Business Decisions.</h1><p class="lead">Excel, Power BI and interactive HTML dashboards that make complex data clear, built on years of real-world health data analysis and reporting.</p><div class="cta-row"><a class="btn btn-primary" href="#portfolio">Explore Portfolio {ARR}</a><a class="btn btn-ghost" href="{GEN}" target="_blank" rel="noopener">{WAI}Request a Custom Dashboard</a></div><p class="role">Data Analyst | Business Intelligence &amp; Dashboard Developer</p></div><div class="collage">{collage}</div></div></section>
<section class="strip"><div class="wrap"><div class="grid g3"><div class="fact"><b>Ministry of Health, Egypt</b><span>Infectious Diseases Division. Data analysis and disease surveillance reporting since Oct 2017</span></div><div class="fact"><b>Freelance dashboard developer</b><span>Excel, Power BI and web dashboards since Jan 2023</span></div><div class="fact"><b>{len(PUB)} projects shown below</b><span>Excel and HTML dashboard screenshots with details</span></div></div></div></section>
<section class="sec" id="about"><div class="wrap"><div class="sec-head"><span class="eyebrow">About Mahmoud</span><h2>Professional profile</h2><p class="lead">Data analyst and dashboard developer with nine years of reporting experience in public health, and freelance Power BI, Excel and web dashboard work for businesses in Saudi Arabia, the UAE, Egypt and Spain.</p></div>
<div class="about-grid"><div><h3 class="sub-h">Experience</h3><div class="tl">
<div class="tl-i rv"><span class="when">Jan 2023 to Present</span><h4>Freelance Data Analyst &amp; Dashboard Developer</h4><p class="muted">Self-employed</p><ul><li>End-to-end BI and dashboard solutions for clients in Saudi Arabia, UAE, Egypt and Spain across healthcare, retail, manufacturing, hospitality, telecom and HR.</li><li>Interactive Power BI and advanced Excel dashboards for performance and KPI monitoring.</li><li>Responsive HTML, CSS and JavaScript KPI dashboards for clients in Spain and the UAE.</li><li>Raw data turned into analysis-ready datasets with Power Query and Excel data modeling.</li><li>AI-assisted business monitoring built with Claude AI for KPI alerts and natural-language questions.</li><li>Automated recurring reporting processes.</li></ul></div>
<div class="tl-i rv"><span class="when">Oct 2017 to Present</span><h4>Data Analyst</h4><p class="muted">Ministry of Health, Infectious Diseases Division</p><ul><li>Analyzed infectious disease datasets to identify epidemiological trends and outbreak indicators.</li><li>Designed and maintained dynamic Excel dashboards and KPI reports for disease surveillance programs.</li><li>Collected, cleaned, validated and transformed large datasets for accurate, consistent reporting.</li><li>Presented findings to ministry leadership and stakeholders through data visualizations.</li><li>Worked with epidemiologists and public health specialists on insights aligned with WHO standards.</li></ul></div></div></div>
<div><h3 class="sub-h">Education</h3><div class="card rv" style="padding:22px"><h4>Bachelor's Degree in Public Health</h4><p class="muted">Specialization in Epidemiology and Health Information Systems. Mansoura University, Egypt. 2021 to 2022.</p></div><h3 class="sub-h" style="margin-top:32px">Courses &amp; certificates</h3><ul class="certs">{cert}</ul>
<div class="cta-row" style="margin-top:32px"><a class="btn btn-primary" href="/assets/cv/Mahmoud-Refat-CV.pdf" download="Mahmoud-Refat-CV.pdf">Download My CV (PDF)</a><a class="btn btn-ghost" href="/assets/cv/Mahmoud-Refat-CV.pdf" target="_blank" rel="noopener">View My CV</a></div></div></div></div></section>
<section class="sec" id="expertise" style="padding-top:0"><div class="wrap"><div class="sec-head"><span class="eyebrow">My Expertise</span><h2>What I bring to your data</h2></div><div class="grid g4">{exp}</div><div class="sec-head" style="margin-top:56px"><h3>Technical skills</h3></div><div class="grid g3">{sk}</div></div></section>
<section class="sec" id="portfolio" style="padding-top:0"><div class="wrap"><div class="sec-head"><span class="eyebrow">Portfolio</span><h2>Dashboards I have built</h2><p class="lead">Browse by technology, open any project for full-size screenshots, and order a similar dashboard on WhatsApp.</p></div>
<div class="tools"><div class="tabs" role="tablist" aria-label="Dashboard category">{tabh}</div><div class="filters"><label class="sr" for="q">Search projects</label><input id="q" class="input" type="search" placeholder="Search projects"><label class="sr" for="ind">Industry</label><select id="ind" class="input"><option value="">All industries</option>{''.join(f'<option>{e(i)}</option>' for i in inds)}</select><button class="btn btn-ghost sm" id="clr" type="button">Clear</button></div></div>
<p class="note" id="status" aria-live="polite"></p>
<div class="grid g3" id="grid" role="tabpanel">{cards}</div>
<div class="empty" id="empty" hidden><h3 id="empty-h">No projects match</h3><p id="empty-p">Try a different search or clear the filters.</p><a class="btn btn-primary" id="empty-wa" href="{wa("Hello Mahmoud,\n\nI visited your Mahmoud BI website and I'd like to see current Power BI dashboard examples.\n\nPlease contact me with more details.\n\nThank you.")}" target="_blank" rel="noopener" hidden>{WAI}Ask for Power BI examples</a></div>
<p class="note small">Figures visible inside screenshots are part of the dashboard design and are not performance claims. Projects shown with sample or illustrative data are labeled.</p></div></section>
<section class="sec" id="services" style="padding-top:0"><div class="wrap"><div class="sec-head"><span class="eyebrow">Services</span><h2>Dashboard and analytics services</h2><p class="lead">Tell me about your data and your goal. I reply on WhatsApp with next steps.</p></div><div class="grid g3">{svc}</div></div></section>
<section class="sec" id="why" style="padding-top:0"><div class="wrap"><div class="sec-head"><span class="eyebrow">Why Work With Me</span><h2>A specialist, not a template</h2></div><div class="whys">{why}</div></div></section>
<section class="sec" id="contact"><div class="wrap"><div class="band" id="custom"><h2>Need a dashboard built for your business?</h2><p class="lead">Tell me about your data, your goal and your deadline. I reply on WhatsApp or email.</p><div class="cta-row" style="justify-content:center"><a class="btn btn-primary" href="{GEN}" target="_blank" rel="noopener">{WAI}Request a Custom Dashboard</a><a class="btn btn-ghost" href="mailto:mahmoudrefat105@gmail.com">Send an email</a></div><ul class="contacts"><li><b>WhatsApp</b><a href="{GEN}" target="_blank" rel="noopener"><span dir="ltr">+20 112 723 8627</span></a></li><li><b>Email</b><a href="mailto:mahmoudrefat105@gmail.com">mahmoudrefat105@gmail.com</a></li><li><b>LinkedIn</b><a href="https://www.linkedin.com/in/mahmoud-refat-b9b988293/" target="_blank" rel="noopener">Mahmoud Refat</a></li><li><b>YouTube</b><a href="https://www.youtube.com/@MahmoudRefatBI" target="_blank" rel="noopener">@MahmoudRefatBI</a></li></ul></div></div></section></main>{footer}
<div class="lb" id="lb" role="dialog" aria-modal="true" aria-label="Project viewer" hidden><button class="lb-x" id="lb-x" aria-label="Close viewer">×</button><div class="lb-stage"><button class="lb-nav prev" id="lb-prev" aria-label="Previous screenshot">‹</button><figure><img id="lb-img" alt="" decoding="async"><figcaption id="lb-cnt" aria-live="polite"></figcaption></figure><button class="lb-nav next" id="lb-next" aria-label="Next screenshot">›</button></div><aside class="lb-info"><div class="tags" id="lb-tags"></div><h3 id="lb-title"></h3><p id="lb-desc"></p><ul id="lb-hl"></ul><div class="lb-thumbs" id="lb-th"></div><a class="btn btn-primary" id="lb-wa" target="_blank" rel="noopener">{WAI}Order This Dashboard</a></aside></div>
<script type="application/json" id="pf-data">{data}</script><script src="/js/ui.js" defer></script><script src="/js/portfolio.js" defer></script></body></html>'''
open(os.path.join(R,'index.html'),'w',encoding='utf-8').write(page)
open(os.path.join(R,'sitemap.xml'),'w').write(f'<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"><url><loc>{SITE}/</loc></url></urlset>\n')
open(os.path.join(R,'robots.txt'),'w').write(f'User-agent: *\nAllow: /\nSitemap: {SITE}/sitemap.xml\n')
print('built',len(PUB),'projects',cnt,'html KB',len(page)//1024)
