# Changelog: Phase 2, Stage 1 (Foundation and Design System)
Branch target: `phase-2-development` (never `main`). Based on Phase 1 v1.1 (launch-ready).

## Added
- `public/css/design-system.css`: tokens (navy, charcoal, orange), type scale, spacing/radius scale, header, mobile drawer, buttons, cards, chips, tags, form fields, hero, dashboard visual, strip, CTA band, footer, scroll reveal. Logical CSS properties so RTL mirrors automatically.
- `public/css/fonts.css` + `public/fonts/`: self-hosted Outfit, Inter and IBM Plex Sans Arabic (open-source licences included). No Google Fonts request on new pages.
- `public/js/ui.js`: mobile drawer (aria-expanded, Escape, closes on link) and reveal-on-scroll. No dependencies.
- `public/design-system.html`: design-system documentation page (noindex).
- `public/preview/home-concept.html` and `home-concept-ar.html`: homepage visual-direction previews in English LTR and Arabic RTL (noindex).
- `public/assets/logo/mahmoud-bi-logo-480.png/.webp` and `-960.png`: resized copies of the same official logo (same artwork, 14 KB webp vs 710 KB). The original files are untouched.
- `tools/gen_preview.py`: local helper that writes the preview pages. Not part of the Cloudflare build.

## Changed
- `public/_headers`: added one rule, long-term caching for `/fonts/*`.

## Unchanged (verified byte-for-byte against the v1.1 backup)
All Phase 1 pages, scripts, stylesheet, logo files, `404.html` and `robots.txt`. The live Phase 1 experience (light theme) is not yet replaced; the new theme applies to real pages in the next stage.

## Design decisions
- Orange accent #FF7900 (from the logo), navy and charcoal surfaces, no gold.
- Logo shown on a white rounded badge, not recolored.
- Button text is navy on orange (7.38:1). White on orange is only 2.63:1, so the Phase 1 buttons would fail AA; they get fixed when real pages are migrated.
- Hero dashboard visual contains no numbers and is captioned "Illustrative visual. Not real data."
- No SQL or Python claims. TikTok hidden. CV shown as a disabled "available soon" button, not a fake link.
- Portfolio cards in the preview are labeled placeholders with no real client or brand names.
