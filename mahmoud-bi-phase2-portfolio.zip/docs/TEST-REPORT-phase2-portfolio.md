# Test report: Phase 2, Portfolio and Client Order System
Chromium (Playwright) on a local server, plus the Wrangler Pages emulator. Self-hosted fonts loaded for real.

## PASS (executed): 94 browser checks, 0 failures
- Layout at 1440, 1024, 768, 390 and 320 px: no console errors or warnings, no failed requests, no horizontal overflow, only same-origin requests, all visible images load, alt text on every image, one H1.
- Navigation: every in-page anchor resolves; each menu link scrolls to its section; legacy anchors exist; sticky header; mobile drawer opens full height and its links scroll and close it.
- Portfolio: tab counts 16/10/0/6; Excel tab 10; HTML tab 6; Power BI tab shows an honest "being prepared" state with a WhatsApp request; search, no-match state, industry filter, tab plus industry, Clear, live status text, deep links `#excel #html #power-bi`.
- WhatsApp: all 16 order buttons match the required message template exactly (project name and technology differ per project), URLs are encoded (no spaces or line breaks), number 201127238627, new tab with noopener, 16 unique messages; 7 service buttons name their service; header, hero, footer and contact buttons present; a click opened a new tab. NOT TESTED: the real wa.me page loading and the message appearing in the WhatsApp app (no internet in my environment).
- Viewer: opens from the image and from View Project; full-size image loads (1280 px for the rabies project); description, technology tag and highlights; counter, next, previous, ArrowLeft/ArrowRight, thumbnails; "Order This Dashboard" equals the card link; focus trap; Esc and close button; scroll lock released; focus returns to the opener; loads a full image for all 16 projects; mobile layout keeps the image and the order button inside the screen.
- CV: PDF served as application/pdf and byte-identical to your upload; Download link triggers a real download named Mahmoud-Refat-CV.pdf; View opens a new tab.
- Content rules: no SQL or Python text, no 50%/60% claims, no Contoso or Zebra branding, no TikTok link, CV facts present, JSON-LD valid, og:image absolute and reachable, sitemap and robots served.
- Privacy: none of the 46 held images are anywhere in `public/`; the 17 published originals are byte-identical to your files (pixels also identical).
- Phase 1 preserved: `/explore.html` (5 products, filter, English/Arabic switch) and `/404.html` still work.
- No-JS fallback: reveal-on-scroll content is visible without the `js` class.
- Cloudflare emulator: `/` 200; `/index.html` and `/explore.html` redirect with query kept; PDF, WebP, JPG, sitemap, robots served with correct types; unknown URL returns the 404 page; headers and 7-day image caching apply; 74 files, 5.1 MB, none near the 25 MiB limit.

## FAIL found and fixed during testing
1. "No projects match" box showed while 16 projects were visible (`display:grid` beat the `hidden` attribute). Fixed globally.
2. Reveal-on-scroll hid content when JavaScript was off. Fixed.
3. Thumbnails cropped the edges of wide dashboards. Now fully visible.
4. An early build produced published originals that were not byte-identical; rebuilt and verified identical (17 of 17).

## NOT TESTED
- Real Cloudflare preview deployment (needs your branch push).
- Real WhatsApp opening on a phone and desktop app.
- Safari, Firefox, real tablets and phones.
- Screen reader audit, Lighthouse scores.
- Fonts on the live site (they are self-hosted and loaded locally).

## Known limitations
- Power BI category has no published projects (see CONTENT-REVIEW).
- RabiesWatch screenshots contain a Windows activation watermark.
- English only; `/ar/` is the next stage.
