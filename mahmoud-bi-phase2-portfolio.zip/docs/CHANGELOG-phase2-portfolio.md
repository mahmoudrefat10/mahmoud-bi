# Changelog: Phase 2, Portfolio and Client Order System
Target branch: `phase-2-development` only. Never `main`. Built on the approved foundation (navy, charcoal, orange, logo in white badge).

## New / replaced
- `public/index.html`: new one-page site (replaces the Phase 1 light homepage). Sections: Home, About (CV), Expertise, Portfolio, Services, Why Work With Me, Contact. Old anchors `#about`, `#contact`, `#custom` still exist.
- Portfolio: 16 projects, tabs All / Excel / Power BI / HTML, search, industry filter, Clear, deep links `#excel`, `#power-bi`, `#html`.
- Full-screen viewer: large original screenshot, next/previous, thumbnails, keyboard arrows, swipe, Esc, focus trap, description, technology badge, highlights, "Order This Dashboard".
- WhatsApp: every project has "Order Similar Dashboard" and the viewer has "Order This Dashboard", each with its own pre-filled, URL-encoded message to wa.me/201127238627 (opens in a new tab). Header, hero, 7 services, contact band and footer also have WhatsApp buttons. No fake forms.
- CV: `public/assets/cv/Mahmoud-Refat-CV.pdf` with "Download My CV (PDF)" and "View My CV".
- SEO: title, description, canonical, Open Graph and Twitter tags, Person JSON-LD, `sitemap.xml`, `robots.txt`, `assets/og-image.jpg` (1200x630), alt text on every image, lazy loading.
- `public/css/portfolio.css`, `public/js/portfolio.js` (about 6 KB, no libraries), `tools/portfolio_data.py` and `tools/build_site.py` (local generators, not a Cloudflare build step).
- Optimized thumbnails (WebP 720 px) next to byte-identical originals.

## Changed
- `public/robots.txt` (added Sitemap line), `public/css/design-system.css` (reveal animation now degrades without JavaScript), `public/js/ui.js` unchanged from foundation.

## Preserved
- `/explore.html` (Phase 1 store with demo products and its EN/AR switch) and `/404.html` still work. They are no longer linked from the main menu.

## Not built (by design)
- Arabic `/ar/` pages (architecture ready: `lang`/`dir` attributes, content isolated in the build script, no language switch exposed yet).
- Published Power BI projects (see CONTENT-REVIEW).
